#!/usr/bin/env python3
"""
Script para migrar datos de SQLite a Supabase
"""

import sqlite3
import os
import sys
from dotenv import load_dotenv
from supabase import create_client

# Cargar variables de entorno
load_dotenv()

SUPABASE_URL = os.getenv('SUPABASE_URL')
SUPABASE_KEY = os.getenv('SUPABASE_KEY')

if not SUPABASE_URL or not SUPABASE_KEY:
    print("❌ Error: SUPABASE_URL y SUPABASE_KEY deben estar configurados en .env")
    sys.exit(1)

# Conectar a Supabase
supabase = create_client(SUPABASE_URL, SUPABASE_KEY)

# Conectar a SQLite
db_path = '/media/datadisk/sistema-operaciones-web/data/sistema.db'
conn = sqlite3.connect(db_path)
conn.row_factory = sqlite3.Row
cursor = conn.cursor()

# ============================================================
# OBTENER COLUMNAS DE UNA TABLA EN SUPABASE
# ============================================================

def get_supabase_columns(table_name):
    """Obtiene las columnas de una tabla en Supabase"""
    try:
        # Usar información_schema para obtener columnas
        result = supabase.table(table_name).select("*").limit(1).execute()
        if result.data and len(result.data) > 0:
            return list(result.data[0].keys())
        return []
    except Exception as e:
        print(f"  ⚠️ No se pudieron obtener columnas de {table_name}: {e}")
        return []

# ============================================================
# MIGRAR TABLA
# ============================================================

def migrar_tabla(nombre_tabla):
    """Migra una tabla de SQLite a Supabase"""
    print(f"📤 Migrando {nombre_tabla}...")
    
    try:
        # Obtener datos de SQLite
        cursor.execute(f"SELECT * FROM {nombre_tabla}")
        rows = cursor.fetchall()
        
        if not rows:
            print(f"  ⚠️ No hay datos en {nombre_tabla}")
            return 0
        
        # Obtener columnas de Supabase
        supabase_cols = get_supabase_columns(nombre_tabla)
        if not supabase_cols:
            print(f"  ⚠️ No se pudieron obtener columnas de Supabase para {nombre_tabla}")
            supabase_cols = []
        
        # Filtrar solo columnas que existen en Supabase
        data = []
        for row in rows:
            row_dict = dict(row)
            # 🔥 Solo mantener columnas que existen en Supabase
            filtered_dict = {}
            for key, value in row_dict.items():
                if key in supabase_cols or not supabase_cols:
                    # Si value es None o string vacío, convertirlo a None
                    if value is None or value == "":
                        filtered_dict[key] = None
                    else:
                        filtered_dict[key] = value
            data.append(filtered_dict)
        
        if not data:
            print(f"  ⚠️ No hay datos válidos para migrar en {nombre_tabla}")
            return 0
        
        # Insertar en Supabase (por lotes de 50)
        batch_size = 50
        total_insertados = 0
        
        for i in range(0, len(data), batch_size):
            batch = data[i:i+batch_size]
            try:
                response = supabase.table(nombre_tabla).insert(batch).execute()
                total_insertados += len(batch)
                print(f"  ✅ Lote {i//batch_size + 1}: {len(batch)} registros")
            except Exception as e:
                print(f"  ❌ Error en lote: {e}")
                # Intentar uno por uno
                for item in batch:
                    try:
                        supabase.table(nombre_tabla).insert(item).execute()
                        total_insertados += 1
                    except Exception as e2:
                        print(f"    ❌ Error con {item.get('id', 'sin_id')}: {e2}")
        
        print(f"  ✅ {total_insertados} registros migrados a {nombre_tabla}")
        return total_insertados
        
    except Exception as e:
        print(f"  ❌ Error migrando {nombre_tabla}: {e}")
        return 0

# ============================================================
# TABLAS A MIGRAR
# ============================================================

TABLAS = [
    'objetivos',
    'stock_fisico',
    'historico_conteo',
    'movimiento_stock',
    'usuarios',
]

# ============================================================
# EJECUTAR MIGRACIÓN
# ============================================================

print("=" * 60)
print("🚀 INICIANDO MIGRACIÓN A SUPABASE")
print("=" * 60)

total_migrados = 0

for tabla in TABLAS:
    total_migrados += migrar_tabla(tabla)

print("=" * 60)
print(f"✅ MIGRACIÓN COMPLETADA - {total_migrados} registros migrados")
print("=" * 60)

conn.close()