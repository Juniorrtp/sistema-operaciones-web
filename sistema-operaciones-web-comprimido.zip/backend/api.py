from fastapi import FastAPI, HTTPException, Request, Response, Depends
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from fastapi.responses import FileResponse
from typing import List, Optional
from datetime import datetime
import os
import sys
from pydantic import BaseModel
import hashlib
import secrets

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from models import MovimientoCreate, MovimientoUpdate, MetroCreate, DetalleMovimiento
from database import get_db

# ============================================================
# CREAR APP
# ============================================================
app = FastAPI(title="API Sistema de Operaciones")


app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# ============================================================
# AUTENTICACIÓN CON SHA-256
# ============================================================

# Diccionario para almacenar sesiones
sesiones = {}

class LoginRequest(BaseModel):
    username: str
    password: str

def verify_password(plain_password: str, hashed_password: str) -> bool:
    """Verifica si la contraseña coincide con el hash SHA-256"""
    password_hash = hashlib.sha256(plain_password.encode()).hexdigest()
    return password_hash == hashed_password

def get_password_hash(password: str) -> str:
    """Genera hash SHA-256 de una contraseña"""
    return hashlib.sha256(password.encode()).hexdigest()

# ============================================================
# FUNCIÓN PARA VERIFICAR STREAMLIT (API Key)
# ============================================================

# Clave secreta para Streamlit (poner en .env)
STREAMLIT_API_KEY = os.getenv("STREAMLIT_API_KEY", "streamlit-secret-key-2024")

def verify_request(request: Request):
    """Verifica autenticación (cookie o API Key para Streamlit)"""
    
    # Primero verificar si es Streamlit (API Key en header)
    api_key = request.headers.get("X-API-Key")
    if api_key and api_key == STREAMLIT_API_KEY:
        return {"source": "streamlit", "authenticated": True, "user": "streamlit"}
    
    # Si no, verificar cookie de usuario normal
    session_token = request.cookies.get("session_token")
    if session_token and session_token in sesiones:
        return sesiones[session_token]
    
    # Si nada funciona, error 401
    raise HTTPException(status_code=401, detail="No autenticado")

# ============================================================
# ENDPOINTS DE AUTENTICACIÓN
# ============================================================

@app.post("/api/auth/login")
async def login(data: LoginRequest, response: Response):
    """Inicia sesión y crea una cookie de sesión"""
    try:
        db = get_db()
        
        # Buscar usuario
        result = db.client.table("usuarios") \
            .select("*") \
            .eq("username", data.username) \
            .eq("activo", 1) \
            .execute()
        
        if not result.data or len(result.data) == 0:
            raise HTTPException(status_code=401, detail="Usuario o contraseña incorrectos")
        
        user = result.data[0]
        
        # Verificar contraseña
        if not verify_password(data.password, user["password"]):
            raise HTTPException(status_code=401, detail="Usuario o contraseña incorrectos")
        
        # Crear token de sesión simple
        session_token = secrets.token_urlsafe(32)
        sesiones[session_token] = {
            "user_id": user["id"],
            "username": user["username"],
            "nombre": user["nombre"],
            "rol": user["rol"]
        }
        
        # Crear cookie con la sesión
        response.set_cookie(
            key="session_token",
            value=session_token,
            max_age=86400,  # 24 horas
            httponly=True,
            samesite="lax",
            secure=False,
            path="/"
            # Cambiar a True en producción con HTTPS
        )
        
        return {
            "success": True,
            "message": "Login exitoso",
            "user": {
                "id": user["id"],
                "username": user["username"],
                "nombre": user["nombre"],
                "rol": user["rol"]
            }
        }
        
    except HTTPException:
        raise
    except Exception as e:
        print(f"❌ Error en login: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@app.post("/api/auth/logout")
async def logout(response: Response):
    """Cierra sesión eliminando la cookie"""
    response.delete_cookie("session_token")
    return {"success": True, "message": "Sesión cerrada"}

@app.get("/api/auth/me")
async def get_current_user(request: Request):
    """Obtiene el usuario actual desde la cookie"""
    session_token = request.cookies.get("session_token")
    
    if not session_token or session_token not in sesiones:
        raise HTTPException(status_code=401, detail="No autenticado")
    
    return sesiones[session_token]

# ============================================================
# SERVIR ARCHIVOS ESTÁTICOS (Frontend)
# ============================================================

BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
FRONTEND_DIR = os.path.join(BASE_DIR, "frontend")

# Crear directorio frontend si no existe (para Render)
os.makedirs(FRONTEND_DIR, exist_ok=True)

# Montar archivos estáticos
if os.path.exists(os.path.join(FRONTEND_DIR, "css")):
    app.mount("/css", StaticFiles(directory=os.path.join(FRONTEND_DIR, "css")), name="css")
if os.path.exists(os.path.join(FRONTEND_DIR, "js")):
    app.mount("/js", StaticFiles(directory=os.path.join(FRONTEND_DIR, "js")), name="js")
if os.path.exists(os.path.join(FRONTEND_DIR, "movimientos")):
    app.mount("/movimientos", StaticFiles(directory=os.path.join(FRONTEND_DIR, "movimientos")), name="movimientos")
if os.path.exists(os.path.join(FRONTEND_DIR, "metros")):
    app.mount("/metros", StaticFiles(directory=os.path.join(FRONTEND_DIR, "metros")), name="metros")
if os.path.exists(os.path.join(FRONTEND_DIR, "stock")):
    app.mount("/stock", StaticFiles(directory=os.path.join(FRONTEND_DIR, "stock")), name="stock")


@app.get("/")
async def servir_index(request: Request):
    """Sirve la página principal o redirige a login"""
    # ✅ Verificar si tiene sesión
    session_token = request.cookies.get("session_token")
    
    if not session_token or session_token not in sesiones:
        # Si no tiene sesión, redirigir a login
        login_path = os.path.join(FRONTEND_DIR, "login.html")
        if os.path.exists(login_path):
            return FileResponse(login_path)
        return {"error": "login.html no encontrado"}
    
    # Si tiene sesión, mostrar index
    index_path = os.path.join(FRONTEND_DIR, "index.html")
    if os.path.exists(index_path):
        return FileResponse(index_path)
    return {"error": "index.html no encontrado"}

@app.get("/{pagina}.html")
async def servir_pagina(pagina: str):
    """Sirve cualquier página HTML"""
    archivo = os.path.join(FRONTEND_DIR, f"{pagina}.html")
    if os.path.exists(archivo):
        return FileResponse(archivo)
    return {"error": "Página no encontrada"}



stock_cache = {}

def actualizar_cache_stock():
    """Actualiza el cache de stock en memoria"""
    global stock_cache
    try:
        print("🔄 ACTUALIZANDO CACHE DE STOCK...")
        db = get_db()
        
        page = 0
        page_size = 1000
        all_data = []
        
        while True:
            result = db.client.table("movimiento_detalles") \
                .select("codigo, cantidad") \
                .range(page * page_size, (page + 1) * page_size - 1) \
                .execute()
            
            if not result.data:
                break
            
            all_data.extend(result.data)
            print(f"📄 Página {page + 1}: {len(result.data)} registros")
            
            if len(result.data) < page_size:
                break
            
            page += 1
        
        print(f"📊 Total registros traídos: {len(all_data)}")
        
        stock_temp = {}
        for row in all_data:
            cod = row.get('codigo')
            cantidad = row.get('cantidad', 0)
            if cod and cantidad != 0:
                cod_clean = cod.upper().strip()
                stock_temp[cod_clean] = stock_temp.get(cod_clean, 0) + cantidad
        
        stock_cache = stock_temp
        
        positivos = len([k for k, v in stock_cache.items() if v > 0])
        print(f"✅ Cache: {len(stock_cache)} productos, {positivos} con stock positivo")
        
    except Exception as e:
        print(f"❌ Error: {e}")

@app.on_event("startup")
async def startup_event():
    """Carga el stock al iniciar la API"""
    print("🚀 INICIANDO API...")
    actualizar_cache_stock()




@app.get("/api/stock")
async def get_all_stock():
    """Obtiene todo el stock desde el cache"""
    stock_positivo = {k: v for k, v in stock_cache.items() if v > 0}
    return [{"codigo": k, "stock": v} for k, v in stock_positivo.items()]

@app.get("/api/stock/{codigo}")
async def get_stock(codigo: str):
    """Obtiene stock de un producto desde el cache"""
    if not codigo:
        return {"codigo": codigo, "stock": 0}
    stock = stock_cache.get(codigo.upper().strip(), 0)
    return {"codigo": codigo, "stock": stock}

@app.get("/api/stock/debug")
async def debug_stock_cache():
    """Muestra el cache de stock para depuración"""
    return {
        "total_productos": len(stock_cache),
        "productos_con_stock": len([k for k, v in stock_cache.items() if v > 0]),
        "ejemplos": dict(list(stock_cache.items())[:10])
    }


@app.get("/api/movimientos")
async def listar_movimientos(
    request: Request, 
    fecha_desde: Optional[str] = None,
    fecha_hasta: Optional[str] = None,
    movimiento: Optional[str] = None,
    limit: int = 100
):
    user = verify_request(request)
    try:
        db = get_db()
        query = db.client.table("movimiento_general").select("*")
        
        if fecha_desde:
            query = query.gte("fecha", fecha_desde)
        if fecha_hasta:
            query = query.lte("fecha", fecha_hasta)
        if movimiento:
            query = query.eq("movimiento", movimiento)
        
        query = query.order("fecha", desc=True).limit(limit)
        result = query.execute()
        return result.data if result.data else []
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@app.get("/api/movimientos/{id}")
async def obtener_movimiento(id: int,request: Request):
    user = verify_request(request)
    try:
        db = get_db()
        general = db.get_by_id("movimiento_general", id)
        # ✅ AGREGAR
        if 'tipo_perforacion' not in general:
            general['tipo_perforacion'] = None


        if not general:
            raise HTTPException(status_code=404, detail="No encontrado")
        
        detalles = db.client.table("movimiento_detalles").select("*").eq("entrega_id", id).execute()
        general["detalles"] = detalles.data if detalles.data else []
        # ✅ AGREGAR
        for detalle in general["detalles"]:
            if 'cantidad' in detalle:
                detalle['cantidad'] = abs(detalle['cantidad'])

        return general
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@app.post("/api/movimientos")
async def crear_movimiento(data: MovimientoCreate):
    try:
        db = get_db()
        
        cabecera = data.model_dump(exclude={'detalles'})
        # ✅ AGREGAR
        if 'tipo_perforacion' not in cabecera:
            cabecera['tipo_perforacion'] = None

        
        for key in ['operador', 'equipo', 'guardia', 'compania', 'estado', 'turno']:
            if key in cabecera and cabecera[key] == '':
                cabecera[key] = None
        
        result = db.client.table("movimiento_general").insert(cabecera).execute()
        
        if not result.data:
            raise HTTPException(status_code=500, detail="Error al guardar cabecera")
        
        movimiento_id = result.data[0]['id']
        es_salida = data.movimiento == "SALIDA"
        
        for detalle in data.detalles:
            nuevo_detalle = detalle.model_dump()
            nuevo_detalle['entrega_id'] = movimiento_id
            if 'familia' not in nuevo_detalle:
                nuevo_detalle['familia'] = None
            if 'tipo_perforacion' not in nuevo_detalle:
                nuevo_detalle['tipo_perforacion'] = cabecera.get('tipo_perforacion')


            
            if es_salida:
                nuevo_detalle['cantidad'] = -abs(detalle.cantidad)
            else:
                nuevo_detalle['cantidad'] = abs(detalle.cantidad)
            
            db.client.table("movimiento_detalles").insert(nuevo_detalle).execute()
        
        actualizar_cache_stock()
        return {"success": True, "id": movimiento_id}
    except Exception as e:
        print(f"❌ Error al guardar movimiento: {e}")
        import traceback
        traceback.print_exc()
        raise HTTPException(status_code=500, detail=str(e))


@app.put("/api/movimientos/{id}")
async def actualizar_movimiento(id: int, data: MovimientoUpdate):
    try:
        db = get_db()
        
        # Obtener todos los campos que vienen en la actualización
        data_dict = {k: v for k, v in data.dict().items() if v is not None}
        
        # Extraer detalles si vienen
        detalles = data_dict.pop('detalles', None)
        
        # Actualizar cabecera
        if data_dict:
            db.client.table("movimiento_general").update(data_dict).eq("id", id).execute()
            print(f"📝 Cabecera actualizada: {data_dict}")
        
        # Actualizar detalles si se enviaron
        if detalles is not None:
            # Eliminar detalles viejos
            db.client.table("movimiento_detalles").delete().eq("entrega_id", id).execute()
            
            # Obtener el movimiento para saber si es SALIDA
            movimiento = data_dict.get('movimiento', 'INGRESO')
            es_salida = movimiento == "SALIDA"
            
            # Insertar detalles nuevos
            for detalle in detalles:
                # ✅ detalle YA ES un diccionario, no usar .dict()
                nuevo_detalle = detalle  # Ya es un dict
                nuevo_detalle['entrega_id'] = id
                
                # Si es SALIDA, convertir a negativo
                if es_salida:
                    nuevo_detalle['cantidad'] = -abs(nuevo_detalle['cantidad'])
                else:
                    nuevo_detalle['cantidad'] = abs(nuevo_detalle['cantidad'])
                
                db.client.table("movimiento_detalles").insert(nuevo_detalle).execute()
            
            # Actualizar cache de stock
            actualizar_cache_stock()
        
        return {"success": True}
    except Exception as e:
        print(f"❌ Error en actualizar_movimiento: {e}")
        import traceback
        traceback.print_exc()
        raise HTTPException(status_code=500, detail=str(e))


@app.delete("/api/movimientos/{id}")
async def eliminar_movimiento(id: int):
    try:
        db = get_db()
        db.client.table("movimiento_detalles").delete().eq("entrega_id", id).execute()
        db.client.table("movimiento_general").delete().eq("id", id).execute()
        actualizar_cache_stock()
        return {"success": True}
    except Exception as e:
        print(f"Error en eliminar_movimiento: {e}")
        return {"success": False, "error": str(e)}



stock_cache = {}


def actualizar_cache_stock():
    global stock_cache
    try:
        print("🔄 ACTUALIZANDO CACHE DE STOCK...")
        db = get_db()
        
        # 🔥 USAR PAGINACIÓN para traer todos los registros
        page = 0
        page_size = 1000
        all_data = []
        
        while True:
            result = db.client.table("movimiento_detalles") \
                .select("codigo, cantidad") \
                .range(page * page_size, (page + 1) * page_size - 1) \
                .execute()
            
            if not result.data:
                break
            
            all_data.extend(result.data)
            print(f"📄 Página {page + 1}: {len(result.data)} registros")
            
            if len(result.data) < page_size:
                break
            
            page += 1
        
        print(f"📊 Total registros traídos: {len(all_data)}")
        
        stock_temp = {}
        for row in all_data:
            cod = row.get('codigo')
            cantidad = row.get('cantidad', 0)
            if cod and cantidad != 0:
                cod_clean = cod.upper().strip()
                stock_temp[cod_clean] = stock_temp.get(cod_clean, 0) + cantidad
        
        stock_cache = stock_temp
        
        positivos = len([k for k, v in stock_cache.items() if v > 0])
        print(f"✅ Cache: {len(stock_cache)} productos, {positivos} con stock positivo")
        
        top_positivos = sorted([(k, v) for k, v in stock_cache.items() if v > 0], 
                              key=lambda x: x[1], reverse=True)[:10]
        if top_positivos:
            print("📊 Top 10 con stock positivo:")
            for k, v in top_positivos:
                print(f"  {k}: {v}")
        
    except Exception as e:
        print(f"❌ Error: {e}")
        import traceback
        traceback.print_exc()
@app.on_event("startup")
async def startup_event():
    """Carga el stock al iniciar la API"""
    print("🚀 INICIANDO API...")
    actualizar_cache_stock()


@app.get("/api/stock")
async def get_all_stock():
    """Obtiene todo el stock desde el cache (rápido)"""
    # 🔥 Mostrar solo productos con stock > 0
    stock_positivo = {k: v for k, v in stock_cache.items() if v > 0}
    return [{"codigo": k, "stock": v} for k, v in stock_positivo.items()]


@app.get("/api/stock/{codigo}")
async def get_stock(codigo: str):
    """Obtiene stock de un producto desde el cache (rápido)"""
    if not codigo:
        return {"codigo": codigo, "stock": 0}
    stock = stock_cache.get(codigo.upper().strip(), 0)
    return {"codigo": codigo, "stock": stock}



@app.get("/api/stock/debug")
async def debug_stock_cache():
    """Muestra todo el cache de stock para depuración"""
    return {
        "total_productos": len(stock_cache),
        "productos_con_stock": len([k for k, v in stock_cache.items() if v > 0]),
        "ejemplos": dict(list(stock_cache.items())[:10])
    }

@app.get("/api/aceros")
async def buscar_aceros(q: str = "", movimiento: str = "INGRESO"):
    """Busca aceros por código o descripción usando el cache de stock"""
    try:
        print(f"🔍 Buscando aceros: q='{q}', movimiento='{movimiento}'")
        
        db = get_db()
        query = db.client.table("aceros").select("*")
        
        if q and len(q) >= 2:
            query = query.or_(f"codigo.ilike.%{q}%,descripcion.ilike.%{q}%")
        
        result = query.limit(50).execute()
        aceros = result.data if result.data else []
        
        print(f"📦 Encontrados {len(aceros)} aceros en la BD")
        
        if movimiento == "SALIDA":
            aceros_con_stock = []
            for acero in aceros:
                cod = acero.get('codigo', '')
                if cod:
                    cod_clean = cod.upper().strip()
                    # 🔥 Buscar en el cache (rápido)
                    stock = stock_cache.get(cod_clean, 0)
                    if stock > 0:
                        acero['stock'] = stock
                        aceros_con_stock.append(acero)
            
            print(f"✅ {len(aceros_con_stock)} aceros con stock > 0")
            return aceros_con_stock
        
        # INGRESO: mostrar todos con su stock (rápido)
        for acero in aceros:
            cod = acero.get('codigo', '')
            if cod:
                cod_clean = cod.upper().strip()
                acero['stock'] = stock_cache.get(cod_clean, 0)
        
        return aceros
        
    except Exception as e:
        print(f"❌ Error en buscar_aceros: {e}")
        import traceback
        traceback.print_exc()
        return []


@app.get("/api/stock/debug")
async def debug_stock():
    """Muestra el cache actual y el stock real desde Supabase"""
    try:
        db = get_db()
        
        # Stock real desde Supabase
        result = db.client.table("movimiento_detalles").select("codigo, cantidad").execute()
        
        stock_real = {}
        for row in result.data:
            cod = row.get('codigo')
            cantidad = row.get('cantidad', 0)
            if cod and cantidad != 0:
                cod_clean = cod.upper().strip()
                stock_real[cod_clean] = stock_real.get(cod_clean, 0) + cantidad
        
        # Stock en cache
        stock_cache_positivo = {k: v for k, v in stock_cache.items() if v > 0}
        
        return {
            "cache": {
                "total": len(stock_cache),
                "con_stock_positivo": len(stock_cache_positivo),
                "ejemplos": dict(list(stock_cache_positivo.items())[:10])
            },
            "real": {
                "total": len(stock_real),
                "con_stock_positivo": len([k for k, v in stock_real.items() if v > 0]),
                "ejemplos": dict(list({k: v for k, v in stock_real.items() if v > 0}.items())[:10])
            }
        }
    except Exception as e:
        return {"error": str(e)}



@app.get("/api/detalles-movimientos")
async def get_detalles_movimientos():
    """Obtiene TODOS los detalles de movimientos con todos los campos - VERSION 2.0"""
    try:
        print("🚀🚀🚀 NUEVA VERSIÓN DEL ENDPOINT - VERSION 2.0 🚀🚀🚀")
        db = get_db()
        
        page = 0
        page_size = 1000
        all_data = []
        
        while True:
            result = db.client.table("movimiento_detalles") \
                .select("*") \
                .range(page * page_size, (page + 1) * page_size - 1) \
                .execute()
            
            if not result.data:
                break
            
            all_data.extend(result.data)
            print(f"📄 Página {page + 1}: {len(result.data)} registros")
            
            if len(result.data) < page_size:
                break
            
            page += 1
        
        print(f"📦 Total detalles de movimientos: {len(all_data)}")
        return all_data
    except Exception as e:
        print(f"❌ Error: {e}")
        return []
    
@app.get("/api/metros")
async def listar_metros(
    fecha_desde: Optional[str] = None,
    fecha_hasta: Optional[str] = None,
    limit: int = 100
):
    try:
        db = get_db()
        query = db.client.table("metros_general").select("*")
        if fecha_desde:
            query = query.gte("fecha", fecha_desde)
        if fecha_hasta:
            query = query.lte("fecha", fecha_hasta)
        query = query.order("fecha", desc=True).limit(limit)
        result = query.execute()
        return result.data if result.data else []
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@app.get("/api/metros/{id}")
async def obtener_metro(id: int):
    try:
        db = get_db()
        result = db.client.table("metros_general").select("*").eq("id", id).execute()
        if not result.data:
            raise HTTPException(status_code=404, detail="No encontrado")
        
        # Obtener detalles
        detalles = db.client.table("metros_detalles").select("*").eq("registro_id", id).execute()
        metro = result.data[0]
        metro["detalles"] = detalles.data if detalles.data else []
        return metro
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))



@app.get("/api/test-version")
async def test_version():
    """Endpoint de prueba para verificar que el código se actualiza"""
    return {
        "version": "2.0",
        "timestamp": str(datetime.now()),
        "message": "¡Este endpoint confirma que el código está actualizado!"
    }

@app.post("/api/metros")
async def crear_metro(data: dict):
    try:
        db = get_db()
        
        # Separar cabecera y detalles
        detalles = data.pop('detalles', [])
        
        result = db.client.table("metros_general").insert(data).execute()
        if not result.data:
            raise HTTPException(status_code=500, detail="Error al guardar cabecera")
        
        metro_id = result.data[0]['id']
        
        for detalle in detalles:
            detalle['registro_id'] = metro_id
            db.client.table("metros_detalles").insert(detalle).execute()
        
        return {"success": True, "id": metro_id}
    except Exception as e:
        print(f"❌ Error al guardar metro: {e}")
        import traceback
        traceback.print_exc()
        raise HTTPException(status_code=500, detail=str(e))


@app.put("/api/metros/{id}")
async def actualizar_metro(id: int, data: dict):
    try:
        db = get_db()
        
        detalles = data.pop('detalles', [])
        
        # Actualizar cabecera
        db.client.table("metros_general").update(data).eq("id", id).execute()
        
        # Eliminar detalles viejos
        db.client.table("metros_detalles").delete().eq("registro_id", id).execute()
        
        # Insertar detalles nuevos
        for detalle in detalles:
            detalle['registro_id'] = id
            db.client.table("metros_detalles").insert(detalle).execute()
        
        return {"success": True}
    except Exception as e:
        print(f"❌ Error al actualizar metro: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@app.delete("/api/metros/{id}")
async def eliminar_metro(id: int):
    try:
        db = get_db()
        db.client.table("metros_detalles").delete().eq("registro_id", id).execute()
        db.client.table("metros_general").delete().eq("id", id).execute()
        return {"success": True}
    except Exception as e:
        print(f"❌ Error al eliminar metro: {e}")
        raise HTTPException(status_code=500, detail=str(e))


# ============================================================
# OPERADORES
# ============================================================

@app.get("/api/operadores")
async def listar_operadores():
    """Lista todos los operadores"""
    try:
        db = get_db()
        result = db.client.table("operador").select("*").order("nombre").execute()
        return result.data if result.data else []
    except Exception as e:
        print(f"Error en listar_operadores: {e}")
        return []


@app.get("/api/operadores/{id}")
async def obtener_operador(id: int):
    """Obtiene un operador por ID"""
    try:
        db = get_db()
        result = db.client.table("operador").select("*").eq("id", id).execute()
        return result.data[0] if result.data else None
    except Exception as e:
        print(f"Error en obtener_operador: {e}")
        return None


@app.post("/api/operadores")
async def crear_operador(data: dict):
    """Crea un nuevo operador"""
    try:
        db = get_db()
        result = db.client.table("operador").insert(data).execute()
        return {"success": True, "id": result.data[0]['id'] if result.data else None}
    except Exception as e:
        print(f"Error en crear_operador: {e}")
        return {"success": False, "error": str(e)}


@app.put("/api/operadores/{id}")
async def actualizar_operador(id: int, data: dict):
    """Actualiza un operador"""
    try:
        db = get_db()
        db.client.table("operador").update(data).eq("id", id).execute()
        return {"success": True}
    except Exception as e:
        print(f"Error en actualizar_operador: {e}")
        return {"success": False, "error": str(e)}


@app.delete("/api/operadores/{id}")
async def eliminar_operador(id: int):
    """Elimina un operador"""
    try:
        db = get_db()
        db.client.table("operador").delete().eq("id", id).execute()
        return {"success": True}
    except Exception as e:
        print(f"Error en eliminar_operador: {e}")
        return {"success": False, "error": str(e)}



@app.get("/api/equipos")
async def listar_equipos():
    """Lista todos los equipos"""
    try:
        db = get_db()
        result = db.client.table("equipo").select("equipo, compania, tipo_perforacion, ceco_tipo").order("equipo").execute()
        return result.data if result.data else []
    except Exception as e:
        print(f"Error en listar_equipos: {e}")
        return []



@app.get("/api/equipos/{id}")
async def obtener_equipo(id: int):
    """Obtiene un equipo por ID"""
    try:
        db = get_db()
        result = db.client.table("equipo").select("*").eq("id", id).execute()
        return result.data[0] if result.data else None
    except Exception as e:
        print(f"Error en obtener_equipo: {e}")
        return None


@app.post("/api/equipos")
async def crear_equipo(data: dict):
    """Crea un nuevo equipo"""
    try:
        db = get_db()
        result = db.client.table("equipo").insert(data).execute()
        return {"success": True, "id": result.data[0]['id'] if result.data else None}
    except Exception as e:
        print(f"Error en crear_equipo: {e}")
        return {"success": False, "error": str(e)}


@app.put("/api/equipos/{id}")
async def actualizar_equipo(id: int, data: dict):
    """Actualiza un equipo"""
    try:
        db = get_db()
        db.client.table("equipo").update(data).eq("id", id).execute()
        return {"success": True}
    except Exception as e:
        print(f"Error en actualizar_equipo: {e}")
        return {"success": False, "error": str(e)}


@app.delete("/api/equipos/{id}")
async def eliminar_equipo(id: int):
    """Elimina un equipo"""
    try:
        db = get_db()
        db.client.table("equipo").delete().eq("id", id).execute()
        return {"success": True}
    except Exception as e:
        print(f"Error en eliminar_equipo: {e}")
        return {"success": False, "error": str(e)}


@app.get("/api/actividades")
async def listar_actividades():
    """Lista todas las actividades"""
    try:
        db = get_db()
        result = db.client.table("actividad").select("*").order("codigo").execute()
        return result.data if result.data else []
    except Exception as e:
        print(f"Error en listar_actividades: {e}")
        return []




@app.post("/api/stock/conteo")
async def guardar_conteo(data: dict):
    """Guarda un conteo físico de stock"""
    try:
        db = get_db()
        fecha = data.get('fecha')
        datos = data.get('datos', [])
        usuario = data.get('usuario', 'admin')
        
        if not fecha:
            return {"success": False, "message": "Fecha requerida"}
        
        print(f"📝 Guardando conteo: {fecha}, {len(datos)} productos")
        
        # Guardar en la tabla conteo_fisico
        for item in datos:
            db.client.table("conteo_fisico").insert({
                'codigo': item['codigo'],
                'ubicacion': 'TALLER',  # Por defecto
                'cantidad': item['cantidad'],
                'fecha': fecha,
                'usuario': usuario
            }).execute()
        
        return {"success": True, "message": "Conteo guardado correctamente"}
    except Exception as e:
        print(f"❌ Error: {e}")
        return {"success": False, "message": str(e)}

@app.get("/api/stock/conteo/fecha")
async def get_conteo_fecha(fecha: str, ubicacion: str = "TODAS"):
    """Obtiene el conteo físico guardado para una fecha y ubicación"""
    try:
        db = get_db()
        query = db.client.table("conteo_fisico").select("*").eq("fecha", fecha)
        
        if ubicacion and ubicacion != "TODAS":
            query = query.eq("ubicacion", ubicacion)
        
        result = query.execute()
        
        return {
            "success": True,
            "datos": result.data if result.data else []
        }
    except Exception as e:
        print(f"❌ Error: {e}")
        return {"success": False, "datos": [], "message": str(e)}



@app.get("/api/objetivos")
async def get_objetivos():
    """Obtiene todos los objetivos de perforación"""
    try:
        db = get_db()
        result = db.client.table("objetivos").select("*").execute()
        return result.data if result.data else []
    except Exception as e:
        print(f"❌ Error al obtener objetivos: {e}")
        return []

@app.get("/api/objetivos/tipo/{tipo_perforacion}")
async def get_objetivos_por_tipo(tipo_perforacion: str):
    """Obtiene objetivos filtrados por tipo de perforación"""
    try:
        db = get_db()
        result = db.client.table("objetivos") \
            .select("*") \
            .eq("Tipo Perforacion", tipo_perforacion) \
            .execute()
        return result.data if result.data else []
    except Exception as e:
        print(f"❌ Error al obtener objetivos por tipo: {e}")
        return []



@app.get("/api/metros-detalles")
async def get_metros_detalles():
    """Obtiene TODOS los detalles de metros con paginación"""
    try:
        db = get_db()
        
        page = 0
        page_size = 1000
        all_data = []
        
        while True:
            result = db.client.table("metros_detalles") \
                .select("*") \
                .range(page * page_size, (page + 1) * page_size - 1) \
                .execute()
            
            if not result.data:
                break
            
            all_data.extend(result.data)
            
            if len(result.data) < page_size:
                break
            
            page += 1
        
        print(f"📦 Total detalles de metros: {len(all_data)}")
        return all_data
    except Exception as e:
        print(f"❌ Error: {e}")
        return []

@app.get("/api/exportar/excel")
async def exportar_excel(
    desde: str,
    hasta: str,
    tipo: str = "movimientos"  # movimientos, metros, o todos
):
    """Exporta datos a Excel - Una sola hoja con datos repetidos"""
    try:
        import io
        import pandas as pd
        from datetime import datetime
        
        db = get_db()
        
        output = io.BytesIO()
        
        with pd.ExcelWriter(output, engine='openpyxl') as writer:
            
            if tipo == "movimientos" or tipo == "todos":
                # ============================================================
                # MOVIMIENTOS - UNA SOLA HOJA
                # ============================================================
                
                # Obtener movimientos
                mov_result = db.client.table("movimiento_general") \
                    .select("*") \
                    .gte("fecha", desde) \
                    .lte("fecha", hasta) \
                    .order("fecha", desc=True) \
                    .execute()
                
                if mov_result.data:
                    # Obtener IDs para detalles
                    ids = [row['id'] for row in mov_result.data]
                    detalles_result = db.client.table("movimiento_detalles") \
                        .select("*") \
                        .in_("entrega_id", ids) \
                        .execute() if ids else []
                    
                    # Crear diccionario de detalles por entrega_id
                    detalles_por_id = {}
                    for det in detalles_result.data or []:
                        entrega_id = det.get('entrega_id')
                        if entrega_id not in detalles_por_id:
                            detalles_por_id[entrega_id] = []
                        detalles_por_id[entrega_id].append(det)
                    
                    # Construir filas (general + detalles)
                    rows = []
                    for mov in mov_result.data:
                        detalles = detalles_por_id.get(mov['id'], [])
                        
                        if detalles:
                            for det in detalles:
                                row = {
                                    # Generales
                                    'ID': mov.get('id'),
                                    'Fecha': mov.get('fecha'),
                                    'Mes': mov.get('mes'),
                                    'Año': mov.get('ano'),
                                    'Turno': mov.get('turno'),
                                    'Guía': mov.get('guia'),
                                    'Movimiento': mov.get('movimiento'),
                                    'Operador': mov.get('operador'),
                                    'Equipo': mov.get('equipo'),
                                    'Compañía': mov.get('compania'),
                                    'Estado': mov.get('estado'),
                                    # Detalles
                                    'Brazo': det.get('brazo'),
                                    'Código': det.get('codigo'),
                                    'Descripción': det.get('descripcion'),
                                    'Cantidad': det.get('cantidad'),
                                    'Familia': det.get('familia'),
                                    'Motivo': det.get('razon'),
                                }
                                rows.append(row)
                        else:
                            # Si no hay detalles, una fila con datos generales
                            row = {
                                'ID': mov.get('id'),
                                'Fecha': mov.get('fecha'),
                                'Mes': mov.get('mes'),
                                'Año': mov.get('ano'),
                                'Turno': mov.get('turno'),
                                'Guía': mov.get('guia'),
                                'Movimiento': mov.get('movimiento'),
                                'Operador': mov.get('operador'),
                                'Equipo': mov.get('equipo'),
                                'Compañía': mov.get('compania'),
                                'Estado': mov.get('estado'),
                                'Brazo': '',
                                'Código': '',
                                'Descripción': '',
                                'Cantidad': '',
                                'Familia': '',
                                'Motivo': '',
                            }
                            rows.append(row)
                    
                    df = pd.DataFrame(rows)
                    df.to_excel(writer, sheet_name='Movimientos', index=False)
            
            if tipo == "metros" or tipo == "todos":
                # ============================================================
                # METROS - UNA SOLA HOJA
                # ============================================================
                
                # Obtener metros
                met_result = db.client.table("metros_general") \
                    .select("*") \
                    .gte("fecha", desde) \
                    .lte("fecha", hasta) \
                    .order("fecha", desc=True) \
                    .execute()
                
                if met_result.data:
                    # Obtener IDs para detalles
                    ids = [row['id'] for row in met_result.data]
                    detalles_result = db.client.table("metros_detalles") \
                        .select("*") \
                        .in_("registro_id", ids) \
                        .execute() if ids else []
                    
                    # Crear diccionario de detalles por registro_id
                    detalles_por_id = {}
                    for det in detalles_result.data or []:
                        registro_id = det.get('registro_id')
                        if registro_id not in detalles_por_id:
                            detalles_por_id[registro_id] = []
                        detalles_por_id[registro_id].append(det)
                    
                    # Construir filas (general + detalles)
                    rows = []
                    for met in met_result.data:
                        detalles = detalles_por_id.get(met['id'], [])
                        
                        if detalles:
                            for det in detalles:
                                row = {
                                    # Generales
                                    'ID': met.get('id'),
                                    'Fecha': met.get('fecha'),
                                    'Mes': met.get('mes'),
                                    'Año': met.get('ano'),
                                    'Turno': met.get('turno'),
                                    'Operador': met.get('operador'),
                                    'Equipo': met.get('equipo'),
                                    'Compañía': met.get('compania'),
                                    'Tipo Perforación': met.get('tipo_perforacion'),
                                    'Total MP': met.get('total_mp'),
                                    # Detalles
                                    'Brazo': det.get('brazo'),
                                    'Código Actividad': det.get('cod_ac'),
                                    'Actividad': det.get('actividad'),
                                    'Nivel': det.get('nivel_perf'),
                                    'Labor Perf.': det.get('labor_perf'),
                                    'Tipo Roca': det.get('tipo_roca'),
                                    'N° Taladros': det.get('num_tal'),
                                    'Long. Perf.': det.get('lon_perf'),
                                    'Rimados': det.get('rimados'),
                                    'MP Producción': det.get('mp_produccion'),
                                    'MP Rimado': det.get('mp_rimado'),
                                }
                                rows.append(row)
                        else:
                            row = {
                                'ID': met.get('id'),
                                'Fecha': met.get('fecha'),
                                'Mes': met.get('mes'),
                                'Año': met.get('ano'),
                                'Turno': met.get('turno'),
                                'Operador': met.get('operador'),
                                'Equipo': met.get('equipo'),
                                'Compañía': met.get('compania'),
                                'Tipo Perforación': met.get('tipo_perforacion'),
                                'Total MP': met.get('total_mp'),
                                'Brazo': '',
                                'Código Actividad': '',
                                'Actividad': '',
                                'Nivel': '',
                                'Labor Perf.': '',
                                'Tipo Roca': '',
                                'N° Taladros': '',
                                'Long. Perf.': '',
                                'Rimados': '',
                                'MP Producción': '',
                                'MP Rimado': '',
                            }
                            rows.append(row)
                    
                    df = pd.DataFrame(rows)
                    df.to_excel(writer, sheet_name='Metros', index=False)
            
            # Metadatos
            metadata = pd.DataFrame({
                'Campo': ['Fecha Desde', 'Fecha Hasta', 'Tipo', 'Exportación', 'Usuario'],
                'Valor': [
                    desde, 
                    hasta, 
                    tipo,
                    datetime.now().strftime("%d/%m/%Y %H:%M"),
                    'admin'
                ]
            })
            metadata.to_excel(writer, sheet_name='Metadatos', index=False)
        
        output.seek(0)
        
        from fastapi.responses import Response
        return Response(
            content=output.getvalue(),
            media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
            headers={
                "Content-Disposition": f"attachment; filename=Reporte_{tipo}_{desde}_{hasta}.xlsx"
            }
        )
        
    except Exception as e:
        print(f"❌ Error exportando Excel: {e}")
        import traceback
        traceback.print_exc()
        raise HTTPException(status_code=500, detail=str(e))
# ============================================================
# EJECUCIÓN LOCAL
# ============================================================

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)


