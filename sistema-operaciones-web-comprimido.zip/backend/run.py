# === Core ===
streamlit>=1.28.0
pandas>=2.0.0
plotly>=5.14.0

# === Base de Datos ===
supabase>=2.0.0
psycopg2-binary>=2.9.0
sqlalchemy>=2.0.0

# === API ===
fastapi>=0.100.0
uvicorn>=0.23.0
pydantic>=2.0.0
python-dotenv>=1.0.0

# === Excel y Reportes ===
openpyxl>=3.1.0
reportlab>=4.0.0